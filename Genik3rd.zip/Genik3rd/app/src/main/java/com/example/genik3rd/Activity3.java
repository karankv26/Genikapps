package com.example.genik3rd;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Activity3 extends AppCompatActivity {
    private Button button;
    private TextView textView, textView2, textView4, textView5, textView6;
    private EditText editText, editText2,editText3,editText4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_3);
        button = findViewById(R.id.button);
        textView = findViewById(R.id.textView);
        textView2 = findViewById(R.id.textView2);
        textView4 = findViewById(R.id.textView4);
        textView5 = findViewById(R.id.textView5);
        textView6 = findViewById(R.id.textView6);
        editText = findViewById(R.id.editText);
        editText2 = findViewById(R.id.editText2);
        editText3 = findViewById(R.id.editText3);
        editText4 = findViewById(R.id.editText4);


    }
    public void calculate(View view){
        String S = editText.getText().toString();
        int A4 = Integer.parseInt(S);
        String a = editText2.getText().toString();
        int B4 = Integer.parseInt(a);
        String b = editText3.getText().toString();
        int C4 = Integer.parseInt(b);
        String c = editText4.getText().toString();
        int D4 = Integer.parseInt(c);
        int result = D4-C4+7*(A4-B4);
        textView.setText("Stock Required for Maintaining Stipulated Stock of Remdesivir: " + result);
        Toast.makeText(this, "Thanks for using this app", Toast.LENGTH_SHORT).show();
    }
}